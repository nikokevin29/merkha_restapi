<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Faker\Factory as Faker;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create('id_ID');
        for($i=0;$i < 10; $i++){
            DB::table('user')->insert([
                'first_name' => $faker->firstName,
                'last_name' => $faker->lastName,
                'username' => $faker->username,
                'gender' => 'Not Prefer to Say',
                'email' => $faker->email,
                'password' => Hash::make('password'),
                'phone' => $faker->phoneNumber,
                'urlphoto' => $faker->imageUrl(640, 480, 'animals', true),
                'bio' => $faker->word(),
                'followers_count' => $faker->randomNumber(4, true),
                'following_count' => $faker->randomNumber(3, true),
                'created_at' => $faker->datetime(),
                'updated_at' => $faker->datetime(),
            ]);
        }
    }
}
