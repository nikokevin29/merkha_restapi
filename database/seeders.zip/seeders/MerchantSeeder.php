<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Faker\Factory as Faker;

class MerchantSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create('id_ID');
        for($i=0;$i < 10; $i++){
            DB::table('merchant')->insert([
                'id_user' => $faker->randomDigitNot(0),
                'id_merchant_category' => $faker->randomDigitNot(0),
                'id_business_type' => $faker->randomDigitNot(0),
                'name' => $faker->company,
                'address' => $faker->address,
                'phone_number' => $faker->phoneNumber,
                'email' => $faker->email,
                'ktp' => $faker->ean13(),
                'npwp' => $faker->isbn13(),
                'created_at' => $faker->datetime(),
                'updated_at' => $faker->datetime(),
            ]);
        }
    }
}
