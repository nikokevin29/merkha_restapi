<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Faker\Factory as Faker;

class VoucherSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create('id_ID');
        for($i=0;$i < 10; $i++){
            DB::table('voucher')->insert([
                'id_merchant' => $faker->randomDigitNot(0),
                'id_employee' => $faker->randomDigitNot(0),
                'voucher_name' => $faker->firstName,
                'voucher_code' => $faker->lastName,
                'voucher_type' => $faker->lastName,
                'disc_amount' => $faker->numberBetween(1000, 10000),
                'disc_rate' => 10.00,
                'valid_date' => $faker->date(),
                'created_at' => $faker->datetime(),
                'updated_at' => $faker->datetime(),
            ]);
        }
    }
}
