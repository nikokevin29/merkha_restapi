<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Faker\Factory as Faker;

class PaymentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create('id_ID');
        for($i=0;$i < 10; $i++){
            DB::table('payment')->insert([
                'id_order' => $faker->randomDigitNot(0),
                'payment_status' => 'DONE',
                'url_bukti_transfer' =>$faker->imageUrl(640, 480, 'animals', true),
                'created_at' => $faker->datetime(),
                'updated_at' => $faker->datetime(),
            ]);
        }
    }
}
